
<?php $__env->startSection('title','Social Links'); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18">Social Links</h4>

                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(site('name')); ?></a></li>
                                    <li class="breadcrumb-item active">Social Links</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->



                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                                <h4 class="header-title">Social Links</h4>
                                <div class="row">
                                    <div class="col-6">
                                        <p class="card-title-desc">
                                            Available Links
                                        </p>
                                    </div>
                                    <div class="col-6">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add social links')): ?>
                                        <button class="btn btn-success waves-effect waves-light float-right" data-toggle="modal" data-target="#addAirline"><i class="mdi mdi-plus"></i> Add new</button>
                                        <?php endif; ?>
                                    </div>
                                </div>



                                <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>URL</th>

                                        <th class="datatable-nosort">Actions</th>
                                    </tr>
                                    </thead>


                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialLink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($socialLink->name); ?></td>
                                            <td><a href="<?php echo e($socialLink->url); ?>" target="_blank"><?php echo e($socialLink->url); ?></a> </td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update social links')): ?>
                                                    <a href="<?php echo e(route('social.links.edit',$socialLink->slug)); ?>" class="btn btn-sm btn-primary">
                                                        Update
                                                    </a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete social links')): ?>
                                                        <a href="<?php echo e(route('social.links.delete',$socialLink->slug)); ?>"
                                                           class="btn btn-sm btn-danger">Delete</a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center text-danger">No records found</td>
                                        </tr>
                                    <?php endif; ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add social links')): ?>
        <div class="modal fade" tabindex="-1" role="dialog" id="addAirline" aria-labelledby="addAirlineModal" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title mt-0">Add Social Link</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('social.links.store')); ?>" method="post" class="custom-validation"
                              enctype="multipart/form-data" novalidate>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" id="name" data-parsley-minlength="5" value="<?php echo e(old('name')); ?>"
                                       data-parsley-required name="name" class="form-control">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="url">Url</label>
                                <input type="text"  required data-parsley-required value="<?php echo e(old('url')); ?>"
                                        id="url"
                                       name="url" class="form-control">
                                <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color:red;"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <input type="submit" class="btn btn-success waves-effect waves-light" value="Add">
                            </div>
                        </form>
                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->

<?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('back/js/init/form-validation.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\resources\views/back/socials/index.blade.php ENDPATH**/ ?>