<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name')); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="TravelDome-One Solution for your travel." name="description" />
    <meta content="TravelDome" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <!-- slick css -->

    <!-- App Css-->
    <link href="<?php echo e(asset('back/css/app.css')); ?>" rel="stylesheet" type="text/css" />
    <?php echo $__env->yieldContent('style'); ?>
    <script src="<?php echo e(asset('/back/js/app.js')); ?>"></script>



</head>
<body data-sidebar="dark">

<!-- Begin page -->
    <div id="layout-wrapper">
<?php /**PATH C:\xampp\htdocs\ason\resources\views/back/partials/header.blade.php ENDPATH**/ ?>