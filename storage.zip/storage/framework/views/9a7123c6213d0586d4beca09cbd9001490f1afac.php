<audio id="warn-sound">
    <source src="<?php echo e(asset('audio/warning.mp3')); ?>" muted type="audio/mpeg">
</audio>
<audio id="suc-sound">
    <source src="<?php echo e(asset('audio/success.mp3')); ?>" muted type="audio/mpeg">
</audio>
</div>
<?php echo $__env->make('back.partials.right-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('script'); ?>
<?php if(session('warning')): ?>
    <script>
        $('audio#warn-sound').get(0).play();
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        Toast.fire({
            icon: 'error',
            title: '<?php echo e(session('warning')); ?>'
        })
    </script>
<?php endif; ?>
<?php if(session('success')): ?>
    <script>
        $('audio#suc-sound').get(0).play();
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            onOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        });

        Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('success')); ?>'
        })
    </script>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ason\resources\views/back/partials/footer.blade.php ENDPATH**/ ?>