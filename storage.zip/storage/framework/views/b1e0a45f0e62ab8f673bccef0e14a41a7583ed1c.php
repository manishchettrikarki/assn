<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view events','add events'])): ?>
  <li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
      <i class="ti-write"></i>
      <span>Events</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view events')): ?>
        <li><a href="<?php echo e(route('events.index')); ?>"><i class="mdi mdi-page-layout-header-footer"></i>Events</a></li>
      <?php endif; ?>

    </ul>
  </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/Event\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>