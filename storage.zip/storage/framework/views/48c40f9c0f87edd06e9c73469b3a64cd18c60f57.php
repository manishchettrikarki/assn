<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect">
                        <i class="mdi mdi-view-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>






                <?php $__currentLoopData = $modulesName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidebarWidget): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(view()->exists($sidebarWidget.'::back.partials.sidebar-widget')): ?>
                        <?php echo $__env->make($sidebarWidget.'::back.partials.sidebar-widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view activity log')): ?>
                <li>
                    <a href="<?php echo e(route('activity.log')); ?>" class="waves-effect">
                        <i class="mdi mdi-radioactive"></i>
                        <span>Activity Log</span>
                    </a>
                </li>
                    <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view site settings')): ?>
                    <li>
                        <a href="<?php echo e(route('site.settings')); ?>" class="waves-effect">
                            <i class="mdi mdi-cogs"></i>
                            <span>Settings</span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view social links')): ?>
                    <li>
                        <a href="<?php echo e(route('social.links')); ?>" class="waves-effect">
                            <i class="fas fa-users-cog"></i>
                            <span>Social Links</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\xampp\htdocs\ason\resources\views/back/partials/sidebar.blade.php ENDPATH**/ ?>