
























    <!DOCTYPE html>
<html lang="en">

<head>
    <title>ASSN- Associtaion of Spine Surgeons of Nepal | <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon-16x16.png"/>
    <!-- Required meta tags -->
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">


</head>

<body>
<!-- top navbar -->
    <?php echo $__env->make('partials.top-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- top nav ends -->
<!-- menu nav starts -->
    <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- menu nav ends -->    <!-- slider starts -->
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ason\resources\views/layouts/app.blade.php ENDPATH**/ ?>