<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view albums'])): ?>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="ti-write"></i>
            <span>Gallery</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view albums')): ?>
                <li>
                    <a href="<?php echo e(route('albums.index')); ?>">
                        <i class="mdi mdi-page-layout-header-footer"></i>Albums
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view gallery images')): ?>
                <li>
                    <a href="#">
                        <i class="mdi mdi-page-layout-header-footer"></i> All Images
                    </a>
                </li>
            <?php endif; ?>


        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/Gallery\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>