<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view access control','view users'])): ?>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="fas fa-user-tag"></i>
            <span>Users</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view access control')): ?>
                <li><a href="<?php echo e(route('user.roles')); ?>"><i class="fas fa-user-shield"></i> Access Control</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
                <li><a href="<?php echo e(route('users')); ?>"> <i class="fas fa-user-check"></i> Registered Users</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view suspended users')): ?>
                <li><a href="<?php echo e(route('users.suspended')); ?>"> <i class="fas fa-user-slash"></i> Suspended Users</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view deleted users')): ?>
                <li><a href="<?php echo e(route('users.deleted')); ?>"> <i class="fas fa-user-times"></i> Deleted Users</a></li>
            <?php endif; ?>
        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/User\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>