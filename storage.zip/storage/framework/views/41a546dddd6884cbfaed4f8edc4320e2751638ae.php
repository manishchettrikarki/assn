<?php $__env->startSection('title','Past Presidents'); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box d-flex align-items-center justify-content-between">
                            <h4 class="mb-0 font-size-18 pull-left">Past Presidents</h4>


                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(site('name')); ?></a></li>
                                    <li class="breadcrumb-item active">Past Presidents</li>
                                </ol>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- end page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-6">
                                        <h4 class="header-title pull-left">Past Presidents</h4>
                                    </div>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add past president')): ?>
                                        <div class="col-6 d-flex justify-content-end">
                                            <a href="<?php echo e(route('past.president.create')); ?>" class="btn btn-sm btn-success float-right">Add new</a>
                                        </div>
                                    <?php endif; ?>
                                </div>


                                <div class="row">
                                    <div class="col-6">
                                        <p class="card-title-desc">
                                        </p>
                                    </div>
                                </div>
                                <table id="datatable-buttons" class="table table-striped table-bordered dt-responsive " style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Tenure</th>
                                        <th>Duration</th>
                                        <th>Image</th>
                                        <th class="datatable-nosort">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $presidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $president): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($president->name); ?></td>
                                        <td><?php echo e($president->tenure); ?></td>
                                        <td><?php echo e($president->duration); ?></td>
                                        <td>
                                            <img src="<?php echo e($president->image); ?>" alt="" width="80" class="img  img-thumbnail">
                                            </td>

                                        <td>
                                            <a class="btn btn-primary my-3" href="<?php echo e(route('past.president.edit',$president->id)); ?>">Update</a>
                                            <a class="btn btn-danger my-3" href="<?php echo e(route('past.president.delete',$president->id)); ?>">Delete</a>
                                        </td>
                                    </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('back/js/init/form-validation.init.js')); ?>"></script>
    <script>
        var t = $("#datatable-buttons").DataTable({
            scrollCollapse: true,
            autoWidth: false,
            responsive: true,
            processing: true,
            columnDefs: [
                {
                    targets: "datatable-nosort",
                    orderable: false,
                },
                // {
                // render: createManageBtn, data: null, targets: [6]
                // }
            ],
            buttons: [
                'copy','print','csv','pdf'
            ]
        });
        t.on('order.dt search.dt', function () {
            t.column(0, {search: 'applied', order: 'applied'}).nodes().each(function (cell, i) {
                cell.innerHTML = i + 1;
            });
        }).draw();
        //
        // function createManageBtn() {
        //     return '<button  type="button"  class="btn btn-success btn-xs delete">Manage</button>';
        // }
        // function myFunc() {
        //     console.log("Button was clicked!!!");
        // }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.partials.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\Modules/Executive\Resources/views/back/past-presidents/index.blade.php ENDPATH**/ ?>