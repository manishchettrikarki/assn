<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view pages','create pages'])): ?>
<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="ti-write"></i>
        <span>CMS</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view pages')): ?>
            <li><a href="<?php echo e(route('cms.pages')); ?>"><i class="mdi mdi-page-layout-header-footer"></i>Pages</a></li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create pages')): ?>
            <li><a href="<?php echo e(route('cms.pages.create')); ?>"><i class="dripicons-document-edit"></i>Create Page</a></li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view sliders')): ?>
        <li><a href="<?php echo e(route('cms.sliders')); ?>"><i class="mdi mdi-image"></i>Sliders</a></li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view library')): ?>
        <li><a href="<?php echo e(route('cms.library')); ?>"> <i class="ti-gallery"></i> Library</a></li>
        <?php endif; ?>
    </ul>
</li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/CMS\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>