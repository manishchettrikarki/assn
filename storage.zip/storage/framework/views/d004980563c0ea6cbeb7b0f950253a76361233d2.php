<?php $__env->startSection('title','Latest Events'); ?>
<?php $__env->startSection('content'); ?>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($type); ?></li>
        </ol>
    </nav>
    <!-- Heading -->
    <div class="container">
        <div class="heading-about">
            <div class="text-center">
                <h2><?php echo e($type); ?> Events</h2>
                <div class="small-line">

                </div>
            </div>
        </div>
    </div>

    <!-- Tabular format of meeting -->
    <div class="tabsection">
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                <div class="container py-5">
                    <!-- DEMO 1 -->
                    <div class="py-5">
                        <div class="row">
                            <!-- DEMO 1 Item-->
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 mb-3 mb-lg-0">
                                <a href="<?php echo e(route('events.view',$event->slug)); ?>">
                                    <div class="hover hover-1 text-white rounded"><img src="<?php echo e($event->cover_image); ?>" alt="">
                                        <div class="hover-overlay"></div>
                                        <div class="hover-1-content px-5 py-4">
                                            <h3 class="hover-1-title text-uppercase font-weight-bold mb-0"> <?php echo e($event->title); ?></h3>
                                            <p class="hover-1-description font-weight-light mb-0">Start Date: <?php echo e($event->start_date->format('Y-M-D')); ?></p>
                                            <p class="hover-1-description font-weight-light mb-0">End Date: <?php echo e($event->end_date->format('Y-M-D')); ?></p>
                                            <p class="hover-1-description font-weight-light mb-0">Location: <?php echo e($event->location); ?></p>
                                        </div>
                                    </div>
                                </a>
                            </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>





















































































































<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\Modules/Event\Resources/views/events.blade.php ENDPATH**/ ?>