<?php $__env->startSection('title','Contact Us'); ?>
<?php $__env->startSection('content'); ?>

















  <!--== Contact Page Content Start ==-->
  <section id="page-content-wrap">
    <div class="contact-page-wrap section-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="contact-content-inner">
              <div class="row">
                <div class="col-lg-6">
                  <!-- Map Area Start -->
                  <div class="map-area-wrap">
                    <!--  cbx-gmap start
                     <div id="cbx-gmap">
                         <div id="map_canvas" class="cbx-map map_canvas" data-lat="44.5403" data-lng="-78.5463" data-title="" data-content="<strong>6H Dilara Tower</strong><br /> <br />77 Bir Uttam C.R. Dutta Road <br /> Dhaka 1205 "></div>
                     </div>
                      cbx-gmap end -->

                    <div style="max-width:100%;overflow:hidden;color:red;width:500px;height:720px;"><div id="googlemaps-display" style="height:100%; width:100%;max-width:100%;"><iframe style="height:100%;width:100%;border:0;" frameborder="0" src="https://www.google.com/maps/embed/v1/search?q=nepal+medicity+&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"></iframe></div><a class="embeddedmap-code" href="https://www.embed-map.com" id="authorizemaps-data">https://www.embed-map.com</a><style>#googlemaps-display img{max-width:none!important;background:none!important;font-size: inherit;font-weight:inherit;}</style></div>

                  </div>
                  <!-- Map Area End -->
                </div>

                <div class="col-lg-6 m-auto">
                  <div class="contact-form-wrap">
                    <?php if(session()->has('warning')): ?>
                      <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <strong><?php echo e(session('warning')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php endif; ?>
                      <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                          <strong><?php echo e(session('success')); ?></strong>
                          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                      <?php endif; ?>

                    <h3>send message</h3>
                    <form action="<?php echo e(route('contact.send')); ?>" method="post" id="cbx-contact-form">
                      <?php echo csrf_field(); ?>
                      <div class="row">
                        <div class="col">
                          <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required id="name" class="form-control">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>

                        <div class="col">
                          <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required id="email" class="form-control">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>

                      <div class="row">
                        <div class="col">
                          <div class="form-group">
                            <label for="address">Address</label>
                            <input type="text" name="address" value="<?php echo e(old('address')); ?>" id="address" class="form-control">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                        <div class="col">
                          <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" name="phone" value="<?php echo e(old('phone')); ?>" id="phone" class="form-control">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                        </div>
                      </div>


                      <div class="form-group">
                        <label for="message">Message</label>
                        <textarea name="message" id="message" rows="10" cols="80" class="form-control"><?php echo e(old('message')); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input" id="callme" name="callme" value="on">
                        <label class="custom-control-label" for="callme">Call me back</label>
                      </div>

                      <div class="form-group ">
                        <div class="col-md-6">
                          <div class="g-recaptcha"
                               data-sitekey="<?php echo e(env('GOOGLE_RECAPTCHA_PUBLIC')); ?>">
                          </div>
                        </div>
                      </div>

                      <button class="btn btn-reg">Send</button>
                      <div id="cbx-formalert"></div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<script src='https://www.google.com/recaptcha/api.js'></script>
  <!--== Contact Page Content End ==-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\resources\views/contact.blade.php ENDPATH**/ ?>