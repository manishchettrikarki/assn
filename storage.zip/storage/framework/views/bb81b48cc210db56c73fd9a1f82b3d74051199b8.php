
<?php $__env->startSection('title',$event->title); ?>
<?php $__env->startSection('content'); ?>
  <!--== Gallery Page Content Start ==-->
  <section id="page-content-wrap">
    <div class="single-event-page-content section-padding">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="single-event-details">
              <div class="event-thumbnails">
                <div class="event-thumbnail-carousel owl-carousel">
                  <div class="event-thumb-item" style="background-image: url(<?php echo e($event->cover_image); ?>)">
                    <div class="event-meta">
                      <h3><?php echo e($event->title); ?></h3>
                      <a class="event-address" href="#"><i class="fa fa-map-marker"></i> <?php echo e($event->location); ?></a>

                    </div>
                  </div>

                  <div class="event-thumb-item" style="background-image: url(<?php echo e($event->cover_image); ?>)">
                    <div class="event-meta">
                      <h3><?php echo e($event->title); ?></h3>
                      <a class="event-address" href="#"><i class="fa fa-map-marker"></i> <?php echo e($event->location); ?></a>

                    </div>
                  </div>

                  <div class="event-thumb-item" style="background-image: url(<?php echo e($event->cover_image); ?>)">
                    <div class="event-meta">
                      <h3><?php echo e($event->title); ?></h3>
                      <a class="event-address" href="#"><i class="fa fa-map-marker"></i> <?php echo e($event->location); ?></a>

                    </div>
                  </div>
                </div>
                <div class="event-countdown">
                  <div class="event-countdown-counter" data-date="<?php echo e($event->start_date->format('Y/m/d')); ?>"></div>
                  <p>Remaining</p>
                </div>
              </div>
              <h2>Details all Thing About This Event</h2>
                <?php echo $event->description; ?>


              <?php if(isset($event->schedule)): ?>
              <div class="event-schedul">
                <h3>Event Schedule</h3>
                <div class="row">
                  <div class="col-lg-10 m-auto">
                    <?php echo $event->schedule; ?>

                  </div>
                </div>
              </div>
                <?php endif; ?>


            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!--== Gallery Page Content End ==-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\Modules/Event\Resources/views/view.blade.php ENDPATH**/ ?>