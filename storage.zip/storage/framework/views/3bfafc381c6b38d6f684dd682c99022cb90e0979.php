<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view subscribers','send newsletter'])): ?>
    <li>
        <a href="javascript: void(0);" class="has-arrow waves-effect">
            <i class="mdi mdi-email-newsletter"></i>
            <span>Newsletter</span>
        </a>
        <ul class="sub-menu" aria-expanded="false">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view subscribers')): ?>
                <li><a href="<?php echo e(route('newsletter.subscribers')); ?>"> <i class="mdi mdi-email-plus"></i> Subscribers</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create email templates')): ?>
                    <li><a href="<?php echo e(route('newsletter.templates')); ?>"><i class="mdi mdi-email-minus-outline"></i> Templates</a></li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('send newsletter')): ?>
                <li><a href="<?php echo e(route('newsletter.create')); ?>"><i class="mdi mdi-email-send"></i> Send Newsletter</a></li>
            <?php endif; ?>

        </ul>
    </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/Newsletter\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>