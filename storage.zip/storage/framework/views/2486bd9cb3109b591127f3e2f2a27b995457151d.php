<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view executive members','view members','view regional coordinators'])): ?>
  <li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
      <i class="ti-write"></i>
      <span>ASON Members</span>
    </a>
    <ul class="sub-menu" aria-expanded="false">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view executive members')): ?>
        <li>
            <a href="<?php echo e(route('executives.index')); ?>">
                <i class="mdi mdi-page-layout-header-footer"></i>Executive Members
            </a>
        </li>
      <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view members')): ?>
            <li>
                <a href="<?php echo e(route('members.index')); ?>">
                    <i class="mdi mdi-page-layout-header-footer"></i> Members
                </a>
            </li>
            <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view regional coordinators')): ?>
              <li>
                  <a href="<?php echo e(route('coordinators.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i> Regional Coordinators
                  </a>
              </li>
          <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update executive message')): ?>
          <li>
            <a href="<?php echo e(route('executive.message')); ?>">
              <i class="mdi mdi-page-layout-header-footer"></i>Executive Messages
            </a>
          </li>
        <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update past presidents')): ?>
              <li>
                  <a href="<?php echo e(route('past.president.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i>Past Presidents
                  </a>
              </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update executive bodies')): ?>
              <li>
                  <a href="<?php echo e(route('executive.bodies.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i>Executive Body
                  </a>
              </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update past general secretary')): ?>
              <li>
                  <a href="<?php echo e(route('past.general.secretary.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i>Past General Secretary
                  </a>
              </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update scientific committee')): ?>
              <li>
                  <a href="<?php echo e(route('scientific.committee.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i>Scientific Committee
                  </a>
              </li>
          <?php endif; ?>
          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update provincial representative')): ?>
              <li>
                  <a href="<?php echo e(route('provincial.representative.index')); ?>">
                      <i class="mdi mdi-page-layout-header-footer"></i>Provincial Representative
                  </a>
              </li>
          <?php endif; ?>
    </ul>
  </li>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\ason\Modules/Executive\Resources/views/back/partials/sidebar-widget.blade.php ENDPATH**/ ?>