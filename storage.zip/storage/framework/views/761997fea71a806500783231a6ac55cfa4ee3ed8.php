<?php $__env->startSection('title','Provincial Representative'); ?>
<?php $__env->startSection('content'); ?>
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Provincial Representative</li>
        </ol>
    </nav>

    <!-- Heading -->
    <div class="container">
        <div class="heading-about">
            <div class="text-center">
                <h2>Provincial Representative</h2>
                <div class="small-line"></div>
            </div>
        </div>
    </div>

    <!-- Members photos section start -->
    <div class="team-area sp">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $representatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $representative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-md-4 col-lg-4 single-team">
                        <div class="inner">
                            <div class="team-img">
                                <img src="<?php echo e($representative->image); ?>" alt="Member Photo">
                            </div>
                            <div class="team-content">
                                <h4><?php echo e($representative->name); ?></h4>
                                <h5><?php echo e($representative->email); ?></h5>
                                <h5><?php echo e($representative->designation); ?></h5>
                                <h5><?php echo e($representative->membertype); ?></h5>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\Modules/Executive\Resources/views/provincial-representative.blade.php ENDPATH**/ ?>