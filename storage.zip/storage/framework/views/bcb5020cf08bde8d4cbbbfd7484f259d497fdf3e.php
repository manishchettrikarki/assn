<?php $__env->startSection('title',$page->title); ?>
<?php $__env->startSection('meta'); ?>
    <meta name="title" content="<?php echo e($page->meta_title); ?>">
    <meta name="description" content="<?php echo e($page->meta_description); ?>">
    <meta name="keywords" content="<?php echo e($page->tags); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <?php echo $page->content; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ason\Modules/CMS\Resources/views/page.blade.php ENDPATH**/ ?>